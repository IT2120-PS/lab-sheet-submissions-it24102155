setwd("C:\\Users\\it24102155\\Desktop\\IT24102155")
getwd()
  
#execise 1

#Question 1

n <- 50
p <- 0.85

#probability that at least 47 student passed
1 - pbinom(46, size=n, prob=p, lower.tail =TRUE)

#Question 2
lambda <- 12
p_exactly_15 <- dpois(15,lambda)
print(p_exactly_15)
